package com.example.bus.Bus.api.service;

import com.example.bus.Bus.api.config.exception.NotFoudException;
import com.example.bus.Bus.api.model.BusModel;
import com.example.bus.Bus.api.repository.BusRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.swing.text.html.Option;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class CrudImpl implements CrudInterface {

    public static final String KEY = "id";
    public static final String CACHE_NAME = "BusModel";
    @Autowired
    private BusRepository busRepository;


    @Override
    public BusModel create(BusModel busModel) {
        log.info("Criando usuario" + busModel.getName());
        BusModel model = busRepository.save(busModel);
        return model;
    }

    @Override
    @CachePut(cacheNames = CACHE_NAME, key="#id")
    public BusModel update(BusModel busModel, Integer id) {
        busModel.setId(id);
        BusModel modelFind = getById(id);

        return busRepository.save(updtadeField(busModel, modelFind));
    }

    private BusModel updtadeField(BusModel busModel, BusModel actualBusModel){
        return BusModel.builder().city(isNullEmptyOrBlanck(busModel.getCity())? actualBusModel.getCity() : busModel.getCity())
                .id(busModel.getId())
                .name(isNullEmptyOrBlanck(busModel.getName())? actualBusModel.getName() : busModel.getName())
                .slug(isNullEmptyOrBlanck(busModel.getSlug())? actualBusModel.getSlug() : busModel.getSlug())
                .createdAt(actualBusModel.getCreatedAt())
                .state(isNullEmptyOrBlanck(busModel.getState())? actualBusModel.getState() : busModel.getState())
                .updatedAt(new Date())
                .build();
    }

    private boolean isNullEmptyOrBlanck(String value){
        if(value == null || value.isEmpty() || value.isBlank())
            return true;
        return false;

    }

    @Override
    @CacheEvict(cacheNames = CACHE_NAME, key="#identifier")
    public void delete(Integer idBus) {
        if(existsById(idBus))
            busRepository.deleteById(idBus);
        else
             throw new NotFoudException();

    }
    private boolean existsById(Integer id){
        return busRepository.existsById(id);
    }


    @Override
    @Cacheable(cacheNames = "BusModel", key = "#root.target.KEY")
    public BusModel getById(Integer idBus) {
        Optional<BusModel> busModel = busRepository.findById(idBus);
        if(busModel.isPresent())
            return busModel.get();
        else
            throw new NotFoudException();
    }

    @Override
    public List<BusModel> getAll() {
        return busRepository.findAll();
    }
}
