package com.example.bus.Bus.api.model;

public class BusDto {



}
