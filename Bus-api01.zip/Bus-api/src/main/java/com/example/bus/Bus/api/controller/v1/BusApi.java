package com.example.bus.Bus.api.controller.v1;


import com.example.bus.Bus.api.model.BusModel;
import com.example.bus.Bus.api.service.CrudImpl;
import com.example.bus.Bus.api.service.CrudInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController()
@RequestMapping("/bus/v1")
public class BusApi {


    @Autowired
    private CrudInterface busServiceInterface = new CrudImpl();


    @PostMapping("/")
    public  ResponseEntity<BusModel> save(@RequestBody @Validated BusModel busModel){
        BusModel newBus = busServiceInterface.create(busModel);
        return ResponseEntity.ok(newBus);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BusModel> getById(@PathVariable Integer id){
        return ResponseEntity.ok(busServiceInterface.getById(id));
    }

    @GetMapping()
    public ResponseEntity<List<BusModel>> getAll(){
        return ResponseEntity.ok(busServiceInterface.getAll());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity.BodyBuilder delete(@PathVariable Integer id){
        busServiceInterface.delete(id);
        return ResponseEntity.status(200);
    }

    @PutMapping("/{id}")
    public ResponseEntity<BusModel>update(@RequestBody BusModel busModel, @PathVariable Integer id){
        return ResponseEntity.ok(busServiceInterface.update(busModel, id));
    }
}
