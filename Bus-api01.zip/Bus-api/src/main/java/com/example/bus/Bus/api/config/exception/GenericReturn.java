package com.example.bus.Bus.api.config.exception;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class GenericReturn {

    private Long code;
    private String message;

}
