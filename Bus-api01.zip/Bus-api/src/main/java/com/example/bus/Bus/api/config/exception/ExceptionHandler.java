package com.example.bus.Bus.api.config.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ExceptionHandler extends ResponseEntityExceptionHandler {
    @org.springframework.web.bind.annotation.ExceptionHandler(NotFoudException.class)
    public ResponseEntity gandlerNotFoundException(){
        return new ResponseEntity(GenericReturn.builder().code(400L).message("Resounce not found").build(),
                HttpStatus.NOT_FOUND);
    }
}
