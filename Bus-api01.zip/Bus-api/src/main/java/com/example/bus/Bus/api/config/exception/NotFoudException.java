package com.example.bus.Bus.api.config.exception;

public class NotFoudException extends RuntimeException{

}
