package com.example.bus.Bus.api.service;

import com.example.bus.Bus.api.model.BusModel;

import java.util.List;

public interface CrudInterface {

    public BusModel create(BusModel busModel);
    public BusModel update(BusModel busModel, Integer id);
    public void delete(Integer idBus);
    public BusModel getById(Integer idBus);
    public List<BusModel> getAll();
}
